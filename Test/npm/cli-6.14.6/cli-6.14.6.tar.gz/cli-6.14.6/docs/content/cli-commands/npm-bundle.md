---
section: cli-commands 
title: npm-bundle
description: REMOVED
---

# npm-bundle(1)

## REMOVED

### Description

The `npm bundle` command has been removed in 1.0, for the simple reason
that it is no longer necessary, as the default behavior is now to
install packages into the local space.

Just use `npm install` now to do what `npm bundle` used to do.

### See Also

* [npm install](/cli-commands/npm-install)
